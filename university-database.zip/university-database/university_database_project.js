const mongoose = require('mongoose');
const dotenv = require('dotenv');

// تحميل المتغيرات البيئية
const result = dotenv.config();
if (result.error) {
  console.error('Error loading .env file:', result.error);
  process.exit(1);
}

// التحقق من وجود MONGODB_URI
if (!process.env.MONGODB_URI) {
  console.error('MONGODB_URI is not defined in .env file');
  process.exit(1);
}

// الاتصال بـ MongoDB Atlas
mongoose.connect(process.env.MONGODB_URI)
  .then(() => {
    console.log('Connected to MongoDB Atlas');
  })
  .catch(err => {
    console.error('Connection error:', err);
    process.exit(1);
  });

// تعريف Schema للطلاب
const studentSchema = new mongoose.Schema({
  studentId: { type: String, required: true, unique: true },
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  dateOfBirth: { type: Date, required: true },
  department: { type: String, required: true },
  enrollmentYear: { type: Number, required: true },
  gpa: { type: Number, min: 0, max: 4 },
  courses: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Course' }]
});

// تعريف Schema لأعضاء هيئة التدريس
const facultySchema = new mongoose.Schema({
  facultyId: { type: String, required: true, unique: true },
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  department: { type: String, required: true },
  title: { type: String, enum: ['Professor', 'Associate Professor', 'Assistant Professor', 'Lecturer'], required: true },
  officeHours: [{
    day: String,
    startTime: String,
    endTime: String
  }],
  courses: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Course' }]
});

// تعريف Schema للمقررات
const courseSchema = new mongoose.Schema({
  courseCode: { type: String, required: true, unique: true },
  courseName: { type: String, required: true },
  credits: { type: Number, required: true },
  instructor: { type: mongoose.Schema.Types.ObjectId, ref: 'Faculty' },
  students: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Student' }]
});

// إنشاء النماذج
const Student = mongoose.model('Student', studentSchema);
const Faculty = mongoose.model('Faculty', facultySchema);
const Course = mongoose.model('Course', courseSchema);

// دالة لإضافة طالب جديد
async function addStudent(studentData) {
  try {
    const student = new Student(studentData);
    await student.save();
    return student;
  } catch (error) {
    throw new Error(`Error adding student: ${error.message}`);
  }
}

// دالة لإضافة عضو هيئة تدريس
async function addFaculty(facultyData) {
  try {
    const faculty = new Faculty(facultyData);
    await faculty.save();
    return faculty;
  } catch (error) {
    throw new Error(`Error adding faculty: ${error.message}`);
  }
}

// دالة لإضافة مقرر
async function addCourse(courseData) {
  try {
    const course = new Course(courseData);
    await course.save();
    return course;
  } catch (error) {
    throw new Error(`Error adding course: ${error.message}`);
  }
}

// مثال على الاستخدام
async function main() {
  try {
    // التحقق من وجود الطالب
    let newStudent = await Student.findOne({ studentId: 'S001' });
    if (!newStudent) {
      newStudent = await addStudent({
        studentId: 'S001',
        firstName: 'محمد',
        lastName: 'أحمد',
        email: 'mohammed.ahmed@university.com',
        dateOfBirth: new Date('2000-05-15'),
        department: 'علوم الحاسب',
        enrollmentYear: 2023,
        gpa: 3.7
      });
      console.log('Student added:', newStudent);
    } else {
      console.log('Student already exists:', newStudent);
    }

    // التحقق من وجود عضو هيئة التدريس
    let newFaculty = await Faculty.findOne({ facultyId: 'F001' });
    if (!newFaculty) {
      newFaculty = await addFaculty({
        facultyId: 'F001',
        firstName: 'د. علي',
        lastName: 'محمود',
        email: 'ali.mahmoud@university.com',
        department: 'علوم الحاسب',
        title: 'Professor',
        officeHours: [
          { day: 'الأحد', startTime: '10:00', endTime: '12:00' },
          { day: 'الثلاثاء', startTime: '14:00', endTime: '16:00' }
        ]
      });
      console.log('Faculty added:', newFaculty);
    } else {
      console.log('Faculty already exists:', newFaculty);
    }

    // التحقق من وجود المقرر
    let newCourse = await Course.findOne({ courseCode: 'CS101' });
    if (!newCourse) {
      newCourse = await addCourse({
        courseCode: 'CS101',
        courseName: 'مقدمة في البرمجة',
        credits: 3,
        instructor: newFaculty._id
      });
      console.log('Course added:', newCourse);
    } else {
      console.log('Course already exists:', newCourse);
    }
  } catch (error) {
    console.error('Error in main:', error);
  } finally {
    mongoose.connection.close();
  }
}

// تشغيل التطبيق
main().catch(console.error);

module.exports = { Student, Faculty, Course, addStudent, addFaculty, addCourse };