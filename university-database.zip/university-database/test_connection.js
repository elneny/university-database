const mongoose = require('mongoose');
const dotenv = require('dotenv');

dotenv.config();
if (!process.env.MONGODB_URI) {
  console.error('MONGODB_URI is not defined');
  process.exit(1);
}

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('Connected to MongoDB Atlas');
  mongoose.connection.close();
}).catch(err => {
  console.error('Connection error:', err);
});