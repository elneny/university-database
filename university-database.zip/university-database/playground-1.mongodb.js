use('thesisdb');
db.students.find().pretty();